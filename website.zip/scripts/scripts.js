$("#share").jsSocials({
    shares: ["whatsapp", "email", "facebook", "twitter", "pinterest"]
});